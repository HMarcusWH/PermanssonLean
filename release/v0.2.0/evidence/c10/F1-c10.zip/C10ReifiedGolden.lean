import PermanssonResearch.ReverseSolver.C10SixStateBridge
import PermanssonResearch.ReverseSolver.C10FullReceipt
import Mathlib.Tactic

/-! Deterministically reified C10 input-bound receipt.
The source hash identifies the canonical input; it is not a proof.
Canonical input SHA-256: 117e2aa061c58090a6caa269c9b544783106e8a8d2fde62f8244b2036f73354d
The actual rational data and claimed output are fully reified below.
-/
open PermanssonResearch.ReverseSolver.C10
set_option autoImplicit false
set_option maxRecDepth 8192
set_option maxHeartbeats 0

def reifiedRaw : RawInput 6 6 where
  baseline := fun x y => (if x = (0 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (1 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if x = (1 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then ((1 : ℚ) / (2 : ℚ)) else (if y = (2 : Fin 6) then ((1 : ℚ) / (6 : ℚ)) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then ((1 : ℚ) / (3 : ℚ)) else (0 : ℚ)))))) else (if x = (2 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (1 : ℚ) else (if y = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if x = (3 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (1 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if x = (4 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then ((1 : ℚ) / (2 : ℚ)) else ((1 : ℚ) / (2 : ℚ))))))) else (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then ((1 : ℚ) / (4 : ℚ)) else ((3 : ℚ) / (4 : ℚ))))))))))))
  members := fun i x y => (if i = (0 : Fin 6) then (if x = (0 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (1 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if x = (1 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (1 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if x = (2 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (1 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if x = (3 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (1 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if x = (4 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then ((1 : ℚ) / (2 : ℚ)) else ((1 : ℚ) / (2 : ℚ))))))) else (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then ((1 : ℚ) / (4 : ℚ)) else ((3 : ℚ) / (4 : ℚ)))))))))))) else (if i = (1 : Fin 6) then (if x = (0 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (1 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if x = (1 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (1 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if x = (2 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then ((1 : ℚ) / (2 : ℚ)) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then ((1 : ℚ) / (2 : ℚ)) else (0 : ℚ)))))) else (if x = (3 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (1 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if x = (4 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then ((1 : ℚ) / (2 : ℚ)) else ((1 : ℚ) / (2 : ℚ))))))) else (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then ((1 : ℚ) / (4 : ℚ)) else ((3 : ℚ) / (4 : ℚ)))))))))))) else (if i = (2 : Fin 6) then (if x = (0 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (1 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if x = (1 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (1 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if x = (2 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then ((1 : ℚ) / (1000 : ℚ)) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then ((999 : ℚ) / (1000 : ℚ)) else (0 : ℚ)))))) else (if x = (3 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (1 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if x = (4 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then ((1 : ℚ) / (2 : ℚ)) else ((1 : ℚ) / (2 : ℚ))))))) else (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then ((1 : ℚ) / (4 : ℚ)) else ((3 : ℚ) / (4 : ℚ)))))))))))) else (if i = (3 : Fin 6) then (if x = (0 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (1 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if x = (1 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then ((1 : ℚ) / (2 : ℚ)) else (if y = (2 : Fin 6) then ((1 : ℚ) / (6 : ℚ)) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then ((1 : ℚ) / (3 : ℚ)) else (0 : ℚ)))))) else (if x = (2 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (1 : ℚ) else (if y = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if x = (3 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (1 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if x = (4 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then ((1 : ℚ) / (2 : ℚ)) else ((1 : ℚ) / (2 : ℚ))))))) else (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then ((1 : ℚ) / (4 : ℚ)) else ((3 : ℚ) / (4 : ℚ)))))))))))) else (if i = (4 : Fin 6) then (if x = (0 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (1 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if x = (1 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (1 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if x = (2 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (1 : ℚ) else (if y = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if x = (3 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (1 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if x = (4 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then ((1 : ℚ) / (2 : ℚ)) else ((1 : ℚ) / (2 : ℚ))))))) else (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then ((1 : ℚ) / (4 : ℚ)) else ((3 : ℚ) / (4 : ℚ)))))))))))) else (if x = (0 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (1 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if x = (1 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then (1 : ℚ) else (0 : ℚ)))))) else (if x = (2 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then (1 : ℚ) else (0 : ℚ)))))) else (if x = (3 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (1 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if x = (4 : Fin 6) then (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then ((1 : ℚ) / (2 : ℚ)) else ((1 : ℚ) / (2 : ℚ))))))) else (if y = (0 : Fin 6) then (0 : ℚ) else (if y = (1 : Fin 6) then (0 : ℚ) else (if y = (2 : Fin 6) then (0 : ℚ) else (if y = (3 : Fin 6) then (0 : ℚ) else (if y = (4 : Fin 6) then ((1 : ℚ) / (4 : ℚ)) else ((3 : ℚ) / (4 : ℚ)))))))))))))))))
  descriptor := fun x => (if x = (0 : Fin 6) then false else (if x = (1 : Fin 6) then false else (if x = (2 : Fin 6) then true else (if x = (3 : Fin 6) then true else (if x = (4 : Fin 6) then true else true)))))
  comparison := ({(1 : Fin 6), (2 : Fin 6)} : Finset (Fin 6))

/-- This performs the actual Lean row-stochasticity/input validation.
No untrusted numeric validity flags enter the checked structure. -/
def reifiedChecked : CheckedInput reifiedRaw :=
  (validateInput reifiedRaw).get (by decide +kernel)

def reifiedBaseClass0 : Finset (Fin 6) := ({(2 : Fin 6), (3 : Fin 6)} : Finset (Fin 6))
def reifiedBaseClass1 : Finset (Fin 6) := ({(4 : Fin 6), (5 : Fin 6)} : Finset (Fin 6))
def reifiedBaseCert : DirichletCertificate 6 where
  classes := ({reifiedBaseClass0, reifiedBaseClass1} : Finset (Finset (Fin 6)))
  weight := fun C x => (if C = reifiedBaseClass0 then (if x = (0 : Fin 6) then ((1 : ℚ) / (3 : ℚ)) else (if x = (1 : Fin 6) then ((1 : ℚ) / (3 : ℚ)) else (if x = (2 : Fin 6) then (1 : ℚ) else (if x = (3 : Fin 6) then (1 : ℚ) else (if x = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if C = reifiedBaseClass1 then (if x = (0 : Fin 6) then ((2 : ℚ) / (3 : ℚ)) else (if x = (1 : Fin 6) then ((2 : ℚ) / (3 : ℚ)) else (if x = (2 : Fin 6) then (0 : ℚ) else (if x = (3 : Fin 6) then (0 : ℚ) else (if x = (4 : Fin 6) then (1 : ℚ) else (1 : ℚ)))))) else (0 : ℚ)))

def reifiedMember0Class0 : Finset (Fin 6) := ({(1 : Fin 6)} : Finset (Fin 6))
def reifiedMember0Class1 : Finset (Fin 6) := ({(4 : Fin 6), (5 : Fin 6)} : Finset (Fin 6))
def reifiedMember0Cert : DirichletCertificate 6 where
  classes := ({reifiedMember0Class0, reifiedMember0Class1} : Finset (Finset (Fin 6)))
  weight := fun C x => (if C = reifiedMember0Class0 then (if x = (0 : Fin 6) then (1 : ℚ) else (if x = (1 : Fin 6) then (1 : ℚ) else (if x = (2 : Fin 6) then (1 : ℚ) else (if x = (3 : Fin 6) then (1 : ℚ) else (if x = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if C = reifiedMember0Class1 then (if x = (0 : Fin 6) then (0 : ℚ) else (if x = (1 : Fin 6) then (0 : ℚ) else (if x = (2 : Fin 6) then (0 : ℚ) else (if x = (3 : Fin 6) then (0 : ℚ) else (if x = (4 : Fin 6) then (1 : ℚ) else (1 : ℚ)))))) else (0 : ℚ)))

def reifiedMember1Class0 : Finset (Fin 6) := ({(1 : Fin 6)} : Finset (Fin 6))
def reifiedMember1Class1 : Finset (Fin 6) := ({(4 : Fin 6), (5 : Fin 6)} : Finset (Fin 6))
def reifiedMember1Cert : DirichletCertificate 6 where
  classes := ({reifiedMember1Class0, reifiedMember1Class1} : Finset (Finset (Fin 6)))
  weight := fun C x => (if C = reifiedMember1Class0 then (if x = (0 : Fin 6) then (1 : ℚ) else (if x = (1 : Fin 6) then (1 : ℚ) else (if x = (2 : Fin 6) then ((1 : ℚ) / (2 : ℚ)) else (if x = (3 : Fin 6) then ((1 : ℚ) / (2 : ℚ)) else (if x = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if C = reifiedMember1Class1 then (if x = (0 : Fin 6) then (0 : ℚ) else (if x = (1 : Fin 6) then (0 : ℚ) else (if x = (2 : Fin 6) then ((1 : ℚ) / (2 : ℚ)) else (if x = (3 : Fin 6) then ((1 : ℚ) / (2 : ℚ)) else (if x = (4 : Fin 6) then (1 : ℚ) else (1 : ℚ)))))) else (0 : ℚ)))

def reifiedMember2Class0 : Finset (Fin 6) := ({(1 : Fin 6)} : Finset (Fin 6))
def reifiedMember2Class1 : Finset (Fin 6) := ({(4 : Fin 6), (5 : Fin 6)} : Finset (Fin 6))
def reifiedMember2Cert : DirichletCertificate 6 where
  classes := ({reifiedMember2Class0, reifiedMember2Class1} : Finset (Finset (Fin 6)))
  weight := fun C x => (if C = reifiedMember2Class0 then (if x = (0 : Fin 6) then (1 : ℚ) else (if x = (1 : Fin 6) then (1 : ℚ) else (if x = (2 : Fin 6) then ((1 : ℚ) / (1000 : ℚ)) else (if x = (3 : Fin 6) then ((1 : ℚ) / (1000 : ℚ)) else (if x = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if C = reifiedMember2Class1 then (if x = (0 : Fin 6) then (0 : ℚ) else (if x = (1 : Fin 6) then (0 : ℚ) else (if x = (2 : Fin 6) then ((999 : ℚ) / (1000 : ℚ)) else (if x = (3 : Fin 6) then ((999 : ℚ) / (1000 : ℚ)) else (if x = (4 : Fin 6) then (1 : ℚ) else (1 : ℚ)))))) else (0 : ℚ)))

def reifiedMember3Class0 : Finset (Fin 6) := ({(2 : Fin 6), (3 : Fin 6)} : Finset (Fin 6))
def reifiedMember3Class1 : Finset (Fin 6) := ({(4 : Fin 6), (5 : Fin 6)} : Finset (Fin 6))
def reifiedMember3Cert : DirichletCertificate 6 where
  classes := ({reifiedMember3Class0, reifiedMember3Class1} : Finset (Finset (Fin 6)))
  weight := fun C x => (if C = reifiedMember3Class0 then (if x = (0 : Fin 6) then ((1 : ℚ) / (3 : ℚ)) else (if x = (1 : Fin 6) then ((1 : ℚ) / (3 : ℚ)) else (if x = (2 : Fin 6) then (1 : ℚ) else (if x = (3 : Fin 6) then (1 : ℚ) else (if x = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if C = reifiedMember3Class1 then (if x = (0 : Fin 6) then ((2 : ℚ) / (3 : ℚ)) else (if x = (1 : Fin 6) then ((2 : ℚ) / (3 : ℚ)) else (if x = (2 : Fin 6) then (0 : ℚ) else (if x = (3 : Fin 6) then (0 : ℚ) else (if x = (4 : Fin 6) then (1 : ℚ) else (1 : ℚ)))))) else (0 : ℚ)))

def reifiedMember4Class0 : Finset (Fin 6) := ({(1 : Fin 6)} : Finset (Fin 6))
def reifiedMember4Class1 : Finset (Fin 6) := ({(2 : Fin 6), (3 : Fin 6)} : Finset (Fin 6))
def reifiedMember4Class2 : Finset (Fin 6) := ({(4 : Fin 6), (5 : Fin 6)} : Finset (Fin 6))
def reifiedMember4Cert : DirichletCertificate 6 where
  classes := ({reifiedMember4Class0, reifiedMember4Class1, reifiedMember4Class2} : Finset (Finset (Fin 6)))
  weight := fun C x => (if C = reifiedMember4Class0 then (if x = (0 : Fin 6) then (1 : ℚ) else (if x = (1 : Fin 6) then (1 : ℚ) else (if x = (2 : Fin 6) then (0 : ℚ) else (if x = (3 : Fin 6) then (0 : ℚ) else (if x = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if C = reifiedMember4Class1 then (if x = (0 : Fin 6) then (0 : ℚ) else (if x = (1 : Fin 6) then (0 : ℚ) else (if x = (2 : Fin 6) then (1 : ℚ) else (if x = (3 : Fin 6) then (1 : ℚ) else (if x = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if C = reifiedMember4Class2 then (if x = (0 : Fin 6) then (0 : ℚ) else (if x = (1 : Fin 6) then (0 : ℚ) else (if x = (2 : Fin 6) then (0 : ℚ) else (if x = (3 : Fin 6) then (0 : ℚ) else (if x = (4 : Fin 6) then (1 : ℚ) else (1 : ℚ)))))) else (0 : ℚ))))

def reifiedMember5Class0 : Finset (Fin 6) := ({(4 : Fin 6), (5 : Fin 6)} : Finset (Fin 6))
def reifiedMember5Cert : DirichletCertificate 6 where
  classes := ({reifiedMember5Class0} : Finset (Finset (Fin 6)))
  weight := fun C x => (if C = reifiedMember5Class0 then (if x = (0 : Fin 6) then (1 : ℚ) else (if x = (1 : Fin 6) then (1 : ℚ) else (if x = (2 : Fin 6) then (1 : ℚ) else (if x = (3 : Fin 6) then (1 : ℚ) else (if x = (4 : Fin 6) then (1 : ℚ) else (1 : ℚ)))))) else (0 : ℚ))

def reifiedMenu : MenuCertificate 6 6 where
  baseline := reifiedBaseCert
  members := fun i => (if i = (0 : Fin 6) then reifiedMember0Cert else (if i = (1 : Fin 6) then reifiedMember1Cert else (if i = (2 : Fin 6) then reifiedMember2Cert else (if i = (3 : Fin 6) then reifiedMember3Cert else (if i = (4 : Fin 6) then reifiedMember4Cert else reifiedMember5Cert)))))

def reifiedReceipt : FullReceipt 6 6 where
  core := {
    classTables := reifiedMenu
    reportedMargin := fun i => (if i = (0 : Fin 6) then (1 : ℚ) else (if i = (1 : Fin 6) then ((1 : ℚ) / (2 : ℚ)) else (if i = (2 : Fin 6) then ((1 : ℚ) / (1000 : ℚ)) else (if i = (3 : Fin 6) then (0 : ℚ) else (if i = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ))))))
    selectedIndex := (0 : Fin 6)
    reportedOptimum := (1 : ℚ)
    ties := [(0 : Fin 6)]
  }
  baselineEvent := fun x => (if x = (0 : Fin 6) then (1 : ℚ) else (if x = (1 : Fin 6) then (1 : ℚ) else (if x = (2 : Fin 6) then (1 : ℚ) else (if x = (3 : Fin 6) then (1 : ℚ) else (if x = (4 : Fin 6) then (1 : ℚ) else (1 : ℚ))))))
  memberEvent := fun i x => (if i = (0 : Fin 6) then (if x = (0 : Fin 6) then (0 : ℚ) else (if x = (1 : Fin 6) then (0 : ℚ) else (if x = (2 : Fin 6) then (0 : ℚ) else (if x = (3 : Fin 6) then (0 : ℚ) else (if x = (4 : Fin 6) then (1 : ℚ) else (1 : ℚ)))))) else (if i = (1 : Fin 6) then (if x = (0 : Fin 6) then (0 : ℚ) else (if x = (1 : Fin 6) then (0 : ℚ) else (if x = (2 : Fin 6) then ((1 : ℚ) / (2 : ℚ)) else (if x = (3 : Fin 6) then ((1 : ℚ) / (2 : ℚ)) else (if x = (4 : Fin 6) then (1 : ℚ) else (1 : ℚ)))))) else (if i = (2 : Fin 6) then (if x = (0 : Fin 6) then (0 : ℚ) else (if x = (1 : Fin 6) then (0 : ℚ) else (if x = (2 : Fin 6) then ((999 : ℚ) / (1000 : ℚ)) else (if x = (3 : Fin 6) then ((999 : ℚ) / (1000 : ℚ)) else (if x = (4 : Fin 6) then (1 : ℚ) else (1 : ℚ)))))) else (if i = (3 : Fin 6) then (if x = (0 : Fin 6) then (1 : ℚ) else (if x = (1 : Fin 6) then (1 : ℚ) else (if x = (2 : Fin 6) then (1 : ℚ) else (if x = (3 : Fin 6) then (1 : ℚ) else (if x = (4 : Fin 6) then (1 : ℚ) else (1 : ℚ)))))) else (if i = (4 : Fin 6) then (if x = (0 : Fin 6) then (0 : ℚ) else (if x = (1 : Fin 6) then (0 : ℚ) else (if x = (2 : Fin 6) then (1 : ℚ) else (if x = (3 : Fin 6) then (1 : ℚ) else (if x = (4 : Fin 6) then (1 : ℚ) else (1 : ℚ)))))) else (if x = (0 : Fin 6) then (1 : ℚ) else (if x = (1 : Fin 6) then (1 : ℚ) else (if x = (2 : Fin 6) then (1 : ℚ) else (if x = (3 : Fin 6) then (1 : ℚ) else (if x = (4 : Fin 6) then (1 : ℚ) else (1 : ℚ)))))))))))
  pointwiseEffect := fun i x => (if i = (0 : Fin 6) then (if x = (0 : Fin 6) then (1 : ℚ) else (if x = (1 : Fin 6) then (1 : ℚ) else (if x = (2 : Fin 6) then (1 : ℚ) else (if x = (3 : Fin 6) then (1 : ℚ) else (if x = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if i = (1 : Fin 6) then (if x = (0 : Fin 6) then (1 : ℚ) else (if x = (1 : Fin 6) then (1 : ℚ) else (if x = (2 : Fin 6) then ((1 : ℚ) / (2 : ℚ)) else (if x = (3 : Fin 6) then ((1 : ℚ) / (2 : ℚ)) else (if x = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if i = (2 : Fin 6) then (if x = (0 : Fin 6) then (1 : ℚ) else (if x = (1 : Fin 6) then (1 : ℚ) else (if x = (2 : Fin 6) then ((1 : ℚ) / (1000 : ℚ)) else (if x = (3 : Fin 6) then ((1 : ℚ) / (1000 : ℚ)) else (if x = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if i = (3 : Fin 6) then (if x = (0 : Fin 6) then (0 : ℚ) else (if x = (1 : Fin 6) then (0 : ℚ) else (if x = (2 : Fin 6) then (0 : ℚ) else (if x = (3 : Fin 6) then (0 : ℚ) else (if x = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if i = (4 : Fin 6) then (if x = (0 : Fin 6) then (1 : ℚ) else (if x = (1 : Fin 6) then (1 : ℚ) else (if x = (2 : Fin 6) then (0 : ℚ) else (if x = (3 : Fin 6) then (0 : ℚ) else (if x = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))) else (if x = (0 : Fin 6) then (0 : ℚ) else (if x = (1 : Fin 6) then (0 : ℚ) else (if x = (2 : Fin 6) then (0 : ℚ) else (if x = (3 : Fin 6) then (0 : ℚ) else (if x = (4 : Fin 6) then (0 : ℚ) else (0 : ℚ)))))))))))
  worstState := fun i => (if i = (0 : Fin 6) then (1 : Fin 6) else (if i = (1 : Fin 6) then (2 : Fin 6) else (if i = (2 : Fin 6) then (2 : Fin 6) else (if i = (3 : Fin 6) then (1 : Fin 6) else (if i = (4 : Fin 6) then (2 : Fin 6) else (1 : Fin 6))))))

/-- All claims match the COMPLETE exact reified data and the
independently proved C10 certificate checker. Kernel reduction only. -/
theorem reifiedReceipt_valid :
    checkFullReceipt reifiedRaw reifiedChecked reifiedReceipt = true := by
  decide +kernel

/-- The checked reference is a proof term, not a trusted label. -/
theorem reifiedReceipt_conditions :
    FullReceiptConditions reifiedRaw reifiedChecked reifiedReceipt :=
  checkFullReceipt_sound reifiedRaw reifiedChecked reifiedReceipt
    reifiedReceipt_valid

#print axioms reifiedReceipt_valid
#print axioms reifiedReceipt_conditions


/-! # Original C10 six-state release witness

All equality checks are over the *literal reified input*, not a copied
receipt status or an assumed adapter. The six numerical Fin indices are
fixed in SIX_LABELS and in the original sixRaw definition.
-/
set_option maxRecDepth 8192
set_option maxHeartbeats 0

/-- Baseline, every candidate, the global descriptor, and the COMPLETE
frozen comparison set coincide with the original sixRaw protocol. -/
theorem reifiedGolden_data_contract :
    (∀ x y : Fin 6,
      reifiedRaw.baseline x y = sixRaw.baseline x y) ∧
    (∀ i x y : Fin 6,
      reifiedRaw.members i x y = sixRaw.members i x y) ∧
    (∀ x : Fin 6,
      reifiedRaw.descriptor x = sixRaw.descriptor x) ∧
    reifiedRaw.comparison = sixRaw.comparison := by
  refine ⟨?_, ?_, ?_, ?_⟩ <;> decide +kernel

/-- The reified rationals are exactly the complete computed sixRaw
margins at every frozen menu index, not merely a matching printed table. -/
theorem reifiedGolden_numeric_margins :
    ∀ i : Fin 6,
      reifiedReceipt.core.reportedMargin i =
        numericalMargin sixRaw sixChecked sixReference i := by
  decide +kernel

/-- The checked rational equality transports to the untouched original
real B₁ margin using the already proved genuine typed path-law bridge. -/
theorem reifiedGolden_original_margins :
    ∀ i : Fin 6,
      (reifiedReceipt.core.reportedMargin i : ℝ) =
        sixOriginalMargin i := by
  intro i
  rw [sixOriginalMargin_eq_numeric i]
  exact congrArg (fun q : ℚ => (q : ℝ))
    (reifiedGolden_numeric_margins i)

/-- Selection, complete maximizer indices, and optimum are checked from
the literal complete receipt rather than inferred from a name or hash. -/
theorem reifiedGolden_selection :
    reifiedReceipt.core.selectedIndex = (0 : Fin 6) ∧
    reifiedReceipt.core.reportedOptimum = (1 : ℚ) ∧
    reifiedReceipt.core.ties = [(0 : Fin 6)] := by
  decide +kernel

/-- Every listed reified candidate is bounded by the genuine original
full-disruption margin, with the same one intervention at all starts. -/
theorem reifiedGolden_original_global_max (i : Fin 6) :
    (reifiedReceipt.core.reportedMargin i : ℝ) ≤
      sixOriginalMargin (0 : Fin 6) := by
  rw [reifiedGolden_original_margins i]
  exact sixOriginalFull_is_global_max i

#print axioms reifiedGolden_data_contract
#print axioms reifiedGolden_numeric_margins
#print axioms reifiedGolden_original_margins
#print axioms reifiedGolden_selection
#print axioms reifiedGolden_original_global_max
#print axioms PermanssonResearch.ReverseSolver.C10.six_original_baseline_exactGR
