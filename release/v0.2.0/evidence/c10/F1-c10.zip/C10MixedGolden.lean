import PermanssonResearch.ReverseSolver.C10RationalInitialMixture
import PermanssonResearch.ReverseSolver.ExactSixStateC10Execution
import Mathlib.Tactic

/-! The unmodified original six-state menu and two comparison starts,
initialized with exactly 1/2 mass each. Mixing changes neither the
original B₁ nor the fixed-menu maximin optimizer. -/
open PermanssonResearch.ReverseSolver.C10
set_option autoImplicit false
set_option maxRecDepth 8192
set_option maxHeartbeats 0

def mixedGoldenWeights (x : Fin 6) : ℚ :=
  if x = 1 then 1/2 else if x = 2 then 1/2 else 0

def mixedGoldenLaw : RationalInitialLaw 6 :=
  (validateInitialLaw mixedGoldenWeights).get (by decide +kernel)

/-- Exact baseline, full, half, tiny, identity, U-only, B-only
mixed event values from C10's checked rational class receipt. -/
theorem mixedGolden_exact :
    rationalMixedEventValue sixReference.baseline
      sixRaw.descriptor mixedGoldenLaw = 1 ∧
    rationalMixedEventValue (sixReference.members (0 : Fin 6))
      sixRaw.descriptor mixedGoldenLaw = 0 ∧
    rationalMixedEventValue (sixReference.members (1 : Fin 6))
      sixRaw.descriptor mixedGoldenLaw = (1/4 : ℚ) ∧
    rationalMixedEventValue (sixReference.members (2 : Fin 6))
      sixRaw.descriptor mixedGoldenLaw = (999/2000 : ℚ) ∧
    rationalMixedEventValue (sixReference.members (3 : Fin 6))
      sixRaw.descriptor mixedGoldenLaw = 1 ∧
    rationalMixedEventValue (sixReference.members (4 : Fin 6))
      sixRaw.descriptor mixedGoldenLaw = (1/2 : ℚ) ∧
    rationalMixedEventValue (sixReference.members (5 : Fin 6))
      sixRaw.descriptor mixedGoldenLaw = 1 := by
  decide +kernel

#print axioms mixedGolden_exact
#print axioms PermanssonResearch.ReverseSolver.C10.rationalInitialProbability_singleton
#print axioms PermanssonResearch.ReverseSolver.C10.checked_rationalMixedEventValue_eq_actual_path
