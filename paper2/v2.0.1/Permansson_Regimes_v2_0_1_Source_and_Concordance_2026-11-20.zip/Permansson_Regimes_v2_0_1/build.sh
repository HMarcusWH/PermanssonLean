#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
python3 build_index.py
python3 computations/brown_mackay_exact.py
python3 computations/noninvariance_exact.py
python3 computations/x1_exact.py
mkdir -p build
python3 --version > build/build_environment.txt
pdflatex --version >> build/build_environment.txt
latexmk --version >> build/build_environment.txt
latexmk -pdf -interaction=nonstopmode -halt-on-error -file-line-error -outdir=build main.tex
echo 'Built build/main.pdf'
