"""Generate the actual mathematical statement index and structural audit.

This checks links and source presence. It deliberately does not claim semantic
equivalence between a Lean declaration and a prose statement.
"""
from pathlib import Path
import collections
import json
import re

ROOT = Path(__file__).resolve().parent
KINDS = "theorem|proposition|lemma|corollary|claim|definition|assumption|construction|algorithm|example|counterexample|problem|openproblem"
FILES = ([ROOT / "main.tex", ROOT / "abstract.tex"]
         + [ROOT / f"sections/C{i:02d}.tex" for i in range(1, 32)]
         + sorted((ROOT / "appendices").glob("[A-P]_*.tex")))


def main():
    labels = collections.defaultdict(list)
    statements, references, citations, sources = [], [], [], []
    unlabeled_statements, missing_inputs = [], []
    for path in FILES:
        text = path.read_text()
        rel = str(path.relative_to(ROOT))
        for match in re.finditer(r"\\(?:input|missinginput)\{([^}]+)\}", text):
            target = ROOT / match[1]
            if not target.suffix:
                target = target.with_suffix(".tex")
            if not target.exists():
                missing_inputs.append({"file": rel, "input": match[1]})
        for match in re.finditer(r"\\label\{([^}]+)\}", text):
            labels[match[1]].append(rel)
        for match in re.finditer(r"\\(?:ref|eqref|pageref)\{([^}]+)\}", text):
            references.append({"label": match[1], "file": rel})
        for match in re.finditer(r"\\cite(?:p|t|alp|author|year)?(?:\[[^\]]*\])*\{([^}]+)\}", text):
            citations.extend({"key": key.strip(), "file": rel} for key in match[1].split(","))
        for match in re.finditer(r"\\src\{([^}]+)\}\{([^}]+)\}", text):
            previous_labels = list(re.finditer(r"\\label\{([^}]+)\}", text[:match.start()]))
            sources.append({"source_path": match[1], "source_name": match[2], "file": rel,
                            "line": text[:match.start()].count("\n") + 1,
                            "nearest_preceding_label": previous_labels[-1][1] if previous_labels else None,
                            "semantic_correspondence_inferred": False})
        for match in re.finditer(r"\\begin\{("+KINDS+r")\}(?:\[([^\]]*)\])?", text):
            end = text.find("\\end{"+match[1]+"}", match.end())
            chunk = text[match.end():end]
            label = re.search(r"\\label\{([^}]+)\}", chunk)
            if label:
                statements.append({"file": rel, "kind": match[1], "title": match[2] or match[1].capitalize(),
                                   "label": label[1]})
            else:
                unlabeled_statements.append({"file": rel, "kind": match[1],
                                             "line": text[:match.start()].count("\n") + 1})
    bib = set(re.findall(r"@\w+\{([^,]+),", (ROOT/"references.bib").read_text()))
    report = {
        "required_main_sections_present": all((ROOT/f"sections/C{i:02d}.tex").exists() for i in range(1,32)),
        "integral_appendix_count": len(list((ROOT/"appendices").glob("[A-P]_*.tex"))),
        "duplicate_labels": {key: value for key, value in labels.items() if len(value)>1},
        "missing_references": [row for row in references if row["label"] not in labels],
        "missing_bibliography_keys": [row for row in citations if row["key"] not in bib],
        "missing_input_files": missing_inputs,
        "unlabeled_numbered_items": unlabeled_statements,
        "content_files_inspected": len(FILES),
        "numbered_statement_count": len(statements),
        "all_label_count": len(labels), "source_citation_count": len(sources),
        "mathematical_semantic_completeness_certified": False,
    }
    repo = ROOT.parent/"PermanssonLean"
    if repo.exists():
        report["missing_source_paths"] = [row for row in sources if not (repo/row["source_path"]).exists()]
        report["missing_literal_source_labels"] = [
            row for row in sources
            if (repo/row["source_path"]).exists()
            and row["source_name"] not in (repo/row["source_path"]).read_text(errors="replace")
        ]
        report["source_label_check_scope"] = "Literal presence only; not elaborated type or semantic equivalence."
    lines = [r"\begin{longtable}{L{.25\linewidth}L{.62\linewidth}}",
             r"\toprule Item & Statement or construction\\\midrule\endfirsthead",
             r"\toprule Item & Statement or construction\\\midrule\endhead",
             r"\bottomrule\endfoot"]
    for row in statements:
        lines.append(row["kind"].capitalize()+r"~\ref{"+row["label"]+"} & "+row["title"]+r"\\")
    lines.append(r"\end{longtable}")
    (ROOT/"appendices/generated_statement_index.tex").write_text("\n".join(lines)+"\n")
    (ROOT/"coverage").mkdir(exist_ok=True)
    for name, value in [("statement_index",statements),("source_citation_index",sources),("manuscript_structural_audit",report)]:
        (ROOT/"coverage"/(name+".json")).write_text(json.dumps(value,indent=2)+"\n")
    print(json.dumps(report,indent=2))
    assert report["required_main_sections_present"]
    assert report["integral_appendix_count"] == 16
    assert not report["duplicate_labels"]
    assert not report["missing_references"]
    assert not report["missing_bibliography_keys"]
    assert not report["missing_input_files"]
    assert not report["unlabeled_numbered_items"]
    assert not report.get("missing_source_paths",[])
    assert not report.get("missing_literal_source_labels",[])


if __name__ == "__main__":
    main()
