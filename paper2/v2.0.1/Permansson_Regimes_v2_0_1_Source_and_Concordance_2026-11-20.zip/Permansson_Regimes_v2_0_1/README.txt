PERMANSSON REGIMES, SECOND EDITION — REVIEWED MANUSCRIPT DRAFT
20 November 2026

Title: Permansson Regimes: Structure, Intervention, and Computation Beyond Equilibrium
Author: Marcus Hermansson
Version: 2.0.1, reviewed manuscript draft

CONTENTS

main.tex and preamble.tex build the complete manuscript. All 31 main sections
and all 16 integral appendices A–P are included. The appendices are part of the
same paper, not an external replacement for its mathematical arguments.
references.bib contains the bibliography. The generated statement index is
included and can be regenerated from the actual source.

The manuscript is organized into six parts:
 I. Foundations and complete theoretical lineage (sections 1–6).
 II. Occupation, classification and transition (sections 7–10).
 III. Constitutive structure and quantitative preservation (sections 11–16).
 IV. Control, games and multi-agent realization (sections 17–25).
 V. Specialized theory and complete casebook (sections 26–28).
 VI. Algorithms, evidence and research boundaries (sections 29–31).

BUILD

Requires Python 3 and a standard TeX Live or MiKTeX installation with pdfLaTeX,
BibTeX, latexmk, Latin Modern, AMS packages, geometry, microtype, booktabs,
longtable, tabularx, array, multirow, graphicx, xcolor, enumitem, needspace,
TikZ, xurl, hyperref, natbib, fancyhdr, fancyvrb, etoolbox and titlesec.
No third-party Python package is needed for the manuscript calculations.

From this source directory:

    ./build.sh

Or, to typeset without rerunning the calculations:

    python3 build_index.py
    latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=build main.tex

The PDF is written to build/main.pdf. The build script records engine versions
in build/build_environment.txt. build_index.py checks the 31 sections and
16 appendices, labels, internal references and bibliography keys. If a sibling
PermanssonLean checkout exists, it also checks cited source paths. Absence of
a local repository does not prevent typesetting the self-contained paper.

EXACT CALCULATIONS

    python3 computations/brown_mackay_exact.py
    python3 computations/noninvariance_exact.py
    python3 computations/x1_exact.py

The pricing script exhausts the frozen 601-by-601 trigger grid with integer
and Fraction arithmetic. The noninvariance script evaluates the saved-model
witness as an exact rational. The X1 script reconstructs stochastic rows,
terminal values, survival/effects, Poisson identities and incentive advantages
with Fraction arithmetic. Their recorded results accompany the scripts.
These are mathematical/model checks, not newly identified empirical effects.

The revision review also records 389 exact-arithmetic checks: 326 for the
foundations, 43 for the quantitative examples, and 20 for the specialized
algebra. These counts are separate from the 272 X1 checks and the 361,201
pricing trigger pairs. They are calculation checks, not a theorem count or
a replacement for the stated mathematical hypotheses.

SOURCE SNAPSHOT

Mathematical source:
 c5a36cd6189e2a249d5f4bc11f31698917dc8b10
Publication snapshot:
 f0dee1c11a20f96c9a11b380e942b9252e6ebe44
Accepted historical research companion:
 5822cdff0fc360d9e368e10ff5f7576c3141a1b3
Lean toolchain:
 leanprover/lean4:v4.34.0
mathlib revision:
 5ed2965256430c3649e86755f9576b54eca72435

Repository:
 https://github.com/HMarcusWH/PermanssonLean

The publication documentation merge changes none of the 1,607 tracked Lean,
Python and TeX blobs relative to the mathematical source. The paper itself
contains immutable source hyperlinks. This source package does not duplicate
or modify the repository, external dependencies, attached PDFs or raw archive
extraction caches.

COVERAGE AND REVIEW RECORD

coverage/integrated_draft_verification.json gives the current written status.
coverage/manuscript_label_index.json locates every actual manuscript label.
coverage/statement_index.json lists the numbered mathematical items.
coverage/source_citation_index.json records printed source/declaration links.
coverage/all_lean_written_connections.json connects all 798 Lean files to the
written mathematical proof groups or explicit source/evidence contracts.
The per-area source maps explain consolidation and its limits. Those maps
retain the original v2.0 proof-group assessment; their old manuscript hashes,
fragment builds and citation positions are explicitly historical.
coverage/record_roles.json distinguishes retained historical evidence from
the regenerated v2.0.1 navigation and final verification records.
coverage/earlier_paper_written_obligations.json records the 51 reviewed prior
paper obligations and their actual written destinations. Its manuscript
hashes and destinations are refreshed for v2.0.1; the original unresolved
historical reconciliation statuses are retained.
coverage/inventory/ preserves source identities, hashes, lexical declaration
and AST-unit identities, earlier-document occurrences, archive members and
historical source roots without copying raw source texts into the package.
The historical inventory summaries are explicitly frozen pre-draft records;
they are not the current manuscript completion report.

Navigation and mathematical equivalence are separate. A proof-group route
can locate several helper lemmas without independently certifying every
elaborated source type. Explicit source citation, source-to-prose review,
Lean compilation, numerical replay, independent acceptance and empirical
identification remain distinct evidence fields. The draft retains unresolved
fields rather than promoting them to accepted because a chapter exists.
The complete-coverage goal remains in scope. Appendix P states the concrete
stronger and separately evidenced obligations.

STATUS

This is a full written scientific manuscript draft, suitable for substantive
review and further editorial development. It is not a claim of a fresh build
of the entire Lean repository, complete independent declaration-by-declaration
semantic certification, or empirical certification of the historical cases.
The source inventory includes 7,690 lexical Lean declaration/example units;
that count is not the number of independent theorems in the paper.

REVIEW AND IDENTITY

review/REVIEW_REPORT.pdf and review/review_findings.json record the substantive
and editorial review of the delivered v2.0 draft, including corrected proof
arguments, hypotheses, predicate distinctions, source labels and bibliography.
review/source_changes.patch preserves the exact source changes. Earlier PDF QA
records remain explicitly tied to the earlier snapshots they inspected;
review/revision_verification.json and review/pdf_visual_qa.json apply to v2.0.1.

coverage/*pdf_visual_qa.json records inspected snapshots and page ranges.
coverage/final_pdf_qa.json records the final deliverable checks.
MANIFEST.json binds the packaged files to SHA-256 digests. A digest verifies
identity against that manifest, not provenance without a trusted reference.
The final PDF and editable source must retain their own version when revised.
After editing, rerun the statement index, compile references to convergence,
inspect the changed pages, and regenerate the manifest.
