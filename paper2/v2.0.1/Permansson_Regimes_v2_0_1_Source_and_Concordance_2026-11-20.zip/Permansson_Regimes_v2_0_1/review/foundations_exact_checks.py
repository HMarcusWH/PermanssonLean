"""Independent exact-rational spot checks of the displayed foundation fixtures.
These checks supplement the written proof review; they do not compile Lean.
"""
from fractions import Fraction as Q
from math import factorial
from pathlib import Path
import json

checks = []
def check(name, condition):
    assert condition, name
    checks.append(name)
def rowmul(v, M):
    return [sum(v[i]*M[i][j] for i in range(len(v))) for j in range(len(M))]
def colmul(M, v):
    return [sum(a*b for a,b in zip(row,v)) for row in M]
def unit(n, i):
    return [Q(int(i==j)) for j in range(n)]
def matrix(rows):
    return [[Q(x) for x in row] for row in rows]

K4=matrix([[0,1,0,0],[0,Q(1,2),Q(1,6),Q(1,3)],[0,0,1,0],[0,0,0,1]])
for i,row in enumerate(K4): check(f'four-state row normalization {i}',sum(row)==1 and min(row)>=0)
# Reconstruct the two-random-stage kernel from the stated primitives.
states=[(0,0),(0,1),(1,0),(1,1)]
for i,y in enumerate(states):
    out=[Q(0)]*4
    for a in (0,1):
        if y==(0,1) and a==0: world={0:Q(1,3),1:Q(2,3)}
        else: world={1 if y==(0,0) else y[1]:Q(1)}
        for xp,pr in world.items():
            sp=0 if y==(0,0) or (y==(0,1) and a==1) else 1
            out[states.index((sp,xp))]+=Q(1,2)*pr
    check(f'four-state alpha/P/U reconstruction {i}',out==K4[i])
v=unit(4,1)
for n in range(25):
    check(f'four-state endpoint recurrence n={n}',v==[0,Q(1,2)**n,Q(1,3)*(1-Q(1,2)**n),Q(2,3)*(1-Q(1,2)**n)])
    v=rowmul(v,K4)

K6=matrix([[0,1,0,0,0,0],[0,Q(1,2),Q(1,6),0,Q(1,3),0],[0,0,0,1,0,0],[0,0,1,0,0,0],[0,0,0,0,Q(1,2),Q(1,2)],[0,0,0,0,Q(1,4),Q(3,4)]])
for i,row in enumerate(K6): check(f'six-state row normalization {i}',sum(row)==1 and min(row)>=0)
piA=[0,0,Q(1,2),Q(1,2),0,0];piC=[0,0,0,0,Q(1,3),Q(2,3)]
check('six-state stationary law A',rowmul(piA,K6)==piA)
check('six-state stationary law C',rowmul(piC,K6)==piC)
qA=[Q(1,3),Q(1,3),1,1,0,0];qC=[1-a for a in qA]
check('six-state class-selection A harmonic with correct boundaries',colmul(K6,qA)==qA)
check('six-state class-selection C harmonic with correct boundaries',colmul(K6,qC)==qC)
quotient=[0,1,2,2,3,3]
for i in range(6):
    for j in range(4):
        check(f'exact class quotient row {i} fiber {j}',sum(K6[i][z] for z in range(6) if quotient[z]==j)==K4[quotient[i]][j])
v=unit(6,2)
for n in range(25):
    check(f'periodic recurrent marginal n={n}',v==unit(6,2+n%2))
    v=rowmul(v,K6)
soft=[]
for eps in [Q(1,2),Q(1,1000)]:
    L=[row[:] for row in K6];L[1]=unit(6,1);L[2]=[0,eps,0,0,1-eps,0]
    event=[0,0,1-eps,1-eps,1,1]
    check(f'soft target event harmonic epsilon={eps}',colmul(L,event)==event)
    check(f'soft target exact original margin epsilon={eps}',min(1-event[j] for j in (1,2))==eps)
    soft.append([[x>0 for x in row] for row in L])
check('soft half/tiny support equality',soft[0]==soft[1])

base5=matrix([[0,1,0,0,0],[0,0,0,0,1],[0,0,0,1,0],[0,0,0,1,0],[0,0,0,0,1]])
full5=matrix([[Q(1,2),0,Q(1,2),0,0],[0,Q(1,2),0,Q(1,2),0],[0,0,0,1,0],[0,0,0,1,0],[0,0,0,0,1]])
part5=matrix([[0,0,Q(1,2),0,Q(1,2)],[0,0,0,Q(1,2),Q(1,2)],[0,0,0,1,0],[0,0,0,1,0],[0,0,0,0,1]])
for name,M in [('baseline',base5),('full',full5),('partial',part5)]:
    for i,row in enumerate(M): check(f'five-state {name} row normalization {i}',sum(row)==1 and min(row)>=0)
for start in (0,1):
    v=unit(5,start)
    for n in range(25):
        check(f'full-switch survival start={start} n={n}',sum(v[i] for i in (0,1,4))==Q(1,2)**n)
        check(f'full-switch arrival start={start} n={n}',sum(v[i] for i in (2,3))==1-Q(1,2)**n)
        v=rowmul(v,full5)
    v=rowmul(unit(5,start),part5)
    for n in range(1,8):
        check(f'partial-switch survival and route start={start} n={n}',sum(v[i] for i in (0,1,4))==Q(1,2) and sum(v[i] for i in (2,3))==Q(1,2))
        v=rowmul(v,part5)

f1=matrix([[Q(1,2),Q(1,3),Q(1,6)],[0,1,0],[0,0,1]])
f2=matrix([[Q(1,2),Q(1,4),Q(1,4)],[0,1,0],[0,0,1]])
v1=v2=unit(3,0)
for n in range(25):
    check(f'first exit fixture destination A n={n}',v1[1]==Q(2,3)*(1-Q(1,2)**n))
    check(f'nonexit fixture survival n={n}',v2[0]+v2[1]==Q(1,2)+Q(1,2)**(n+1))
    check(f'nonexit fixture destination n={n}',v2[2]==Q(1,2)*(1-Q(1,2)**n))
    v1=rowmul(v1,f1);v2=rowmul(v2,f2)

ones=0
for k in range(25):
    block=2 if k==0 else factorial(k+2)-factorial(k+1)
    if k%2: ones+=block
    a=Q(ones,factorial(k+2))
    check(f'factorial descriptor last-block bound k={k}',abs(a-k%2)<=Q(1,k+2))

result={'status':'passed','exact_checks':len(checks),'arithmetic':'fractions.Fraction integers only','checks':checks,'scope':'Displayed four-state, six-state, five-state switching, first-exit/nonexit, and factorial-block formulas. Finite-time checks supplement the independently reviewed induction and limit proofs. No Lean compilation or full repository execution.'}
path=Path(__file__).with_name('foundations_exact_results.json')
path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
