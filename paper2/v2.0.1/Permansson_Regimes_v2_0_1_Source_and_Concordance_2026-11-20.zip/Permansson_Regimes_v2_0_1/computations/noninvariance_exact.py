"""Recheck the archived abstract diagnostic-region exit witness exactly."""
from fractions import Fraction as F
from pathlib import Path
import json


def clip(x):
    return min(F(1), max(F(0), x))


def certificate():
    rho = F(5237113702365531, 288230376151711744)
    a = F(3270139990282077, 72057594037927936)
    b = F(7457326533285155, 144115188075855872)
    r0 = F(3716882555442927, 9007199254740992)
    rm = F(1713973770302677, 9007199254740992)
    rl = F(1836950253624643, 18014398509481984)
    d = F(7818285571725933, 2305843009213693952)
    m = l = F(2, 5)
    c, k, q, e = F(7, 10), F(17, 20), F(3, 5), F(17, 20)
    r = clip(r0 + rm * m + rl * l)
    raw = q + rho * (1-q) - a * (1-c) * m * q - b * r * k * c * m * q - d * e * q
    result = clip(raw)
    expected = F(242722894340328248277853994894105127, 405648192073033408478945025720320000)
    assert result == expected
    assert 0 < raw < F(3, 5) < 1
    return {"source": "Breaking Persistence v0.2; seed 26100301, position 0, legacy draw 13823",
            "arithmetic": "fractions.Fraction", "next_q": str(result),
            "threshold": "3/5", "positive_exit_gap": str(F(3, 5)-result),
            "clipping_active": raw != result,
            "conclusion": "The declared diagnostic region is not invariant for this saved deterministic model.",
            "empirical_status": "No real-world transition or causal effect inferred."}


if __name__ == "__main__":
    result = certificate()
    Path(__file__).with_name("noninvariance_exact_certificate.json").write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(result, indent=2))
