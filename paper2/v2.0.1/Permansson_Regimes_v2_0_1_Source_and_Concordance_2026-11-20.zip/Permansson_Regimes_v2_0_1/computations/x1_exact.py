#!/usr/bin/env python3
"""Exact X1 arithmetic reproduced from the manuscript's literal alpha/P/U rows.
Uses only Python's standard library. Run from any working directory.
This checks rational mathematics, not a fresh Lean compilation.
"""
from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path
Y=list(product(range(3),range(3),range(2)))
A=list(product(range(2),repeat=2))
def reward(x,a,i):return F(x*a[i],2)-F(193*a[0]*a[1],211)-F(1-x,10)
def pworld(x,a):return max(F(0),min(F(1),(F(9,10) if x else F(1,4))-F(sum(a),4)))
def nextq(y,a,m):
 if not m:return y[:2]
 x=y[2];ref=F(1 if x else -1,20)
 return tuple(max(0,min(2,y[i]+(2*a[i]-1)*((reward(x,a,i)>ref)-(reward(x,a,i)<ref)))) for i in range(2))
def mat(m,restrain=False,reset=False):
 K={}
 for y in Y:
  row={z:F(0) for z in Y}
  rates=[F(0) if restrain else F(1+9*y[i],20) if m else F(y[2],2) for i in range(2)]
  for a in A:
   pa=F(1)
   for i in range(2):pa*=rates[i] if a[i] else 1-rates[i]
   nq=(1,1) if reset else nextq(y,a,m)
   for x in range(2):row[nq+(x,)]+=pa*(pworld(y[2],a) if x else 1-pworld(y[2],a))
  assert sum(row.values())==1
  K[y]=row
 return K
def terminal(K,n,killed=False):
 v={y:F(y[2]) for y in Y}
 for _ in range(n):v={y:(F(y[2]) if killed else 1)*sum(p*v[z] for z,p in row.items()) for y,row in K.items()}
 return v
Ms={(m,a,u):mat(m,a,u) for m,a,u in product(range(2),repeat=3)}
y0=(1,1,1)
expected_h={(0,0,0):['13/20','51/100','227/500'],(0,0,1):['13/20','51/100','227/500'],(1,0,0):['13/20','11367/32000','8381459/32000000'],(1,0,1):['13/20','711/1600','41417/128000']}
for m in range(2):
 for u in range(2):expected_h[(m,1,u)]=['9/10','167/200','3171/4000']
for key,vals in expected_h.items():assert [terminal(Ms[key],n)[y0] for n in (1,2,3)]==list(map(F,vals)),key
for m,vals in [(0,['13/20','169/400','2197/8000']),(1,['13/20','257/800','40183/200000'])]:assert [terminal(Ms[(m,0,0)],n,True)[y0] for n in (1,2,3)]==list(map(F,vals))
act=['3010663529/6400000000','1342445531/2560000000','284197969/512000000','1342445531/2560000000','16986541/32000000','2886717043/5120000000','284197969/512000000','2886717043/5120000000','15243920951/25600000000']
upd=['504938529/6400000000','240750531/2560000000','43977969/512000000','240750531/2560000000','1972791/32000000','285707043/5120000000','43977969/512000000','285707043/5120000000','1244820951/25600000000']
effect_count=0
for m in range(2):
 b=terminal(Ms[(m,0,0)],3)
 for a,u in [(1,0),(0,1),(1,1)]:
  c=terminal(Ms[(m,a,u)],3)
  es=[abs(c[(q1,q2,1)]-b[(q1,q2,1)]) for q1,q2 in product(range(3),repeat=2)]
  ex=list(map(F,upd if not a else act)) if m else [F(0) if not a else F(271,800)]*9
  assert es==ex,(m,a,u,es,ex)
  effect_count+=len(es)
D=67451192848153165852230
nums={(0,0):(25026974365014808326000,185368801689670273395800),(0,1):(9704259849819302684100,158406832814932088454650),(0,2):(-6784522663161284484300,142848561496669483491113),(1,1):(0,144441407109944827464800),(1,2):(-6740798240214946767600,131260418842081976805200),(2,2):(-9130639988870896046400,118313647584833557054400)}
poisson_count=0
for m in range(2):
 g={y:F(nums[tuple(sorted(y[:2]))][y[2]],D) if m else F(5*y[2],3) for y in Y}
 theta=F(44984685451641390245,355006278148174557117) if m else F(5,12)
 for y in Y:
  assert g[y]-sum(Ms[(m,0,0)][y][z]*g[z] for z in Y)==y[2]-theta,(m,y)
  poisson_count+=1
advantage_count=0
for i,x,a in product(range(2),repeat=3):
 v=F(-81 if x else -121,211)
 q=F(0)
 for b in range(2):
  ab=(a,b) if i==0 else (b,a)
  mass=F(x,2) if b else 1-F(x,2)
  pr=pworld(x,ab)
  q+=mass*(reward(x,ab,i)+F(9,10)*(pr*F(-81,211)+(1-pr)*F(-121,211)))
 assert v-q==F(9,211)*(not x)*a
 advantage_count+=1
out={'status':'PASS','method':'Independent Fraction arithmetic from literal alpha/P/U and rewards, compared with manuscript constants','row_normalization_checks':8*18,'horizon_value_checks':8*3,'survival_checks':6,'effect_table_checks':effect_count,'poisson_row_checks':poisson_count,'player_advantage_checks':advantage_count,'source_compile_claim':False}
print(json.dumps(out,indent=2))
result_path=Path(__file__).resolve().parent.parent/'coverage/control_x1_arithmetic_validation.json'
result_path.parent.mkdir(exist_ok=True)
result_path.write_text(json.dumps(out,indent=2))
