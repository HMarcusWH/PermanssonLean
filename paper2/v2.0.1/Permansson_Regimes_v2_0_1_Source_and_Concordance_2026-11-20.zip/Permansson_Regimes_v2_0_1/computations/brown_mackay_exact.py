"""Exact arithmetic for the frozen BM-FG-TURN-0.005-v0.4 model.

This verifies the declared finite model only. It makes no inference about a
continuous-action game or empirical pricing. All comparisons use Python integers.
Run: python3 computations/brown_mackay_exact.py
"""
from fractions import Fraction
from pathlib import Path
import json

GRID = range(601)
DEN = 160_000


def profit(i, j):
    """Profit numerator for own price i/200 and other price j/200."""
    return i * (800 - 3 * i + 2 * j)


def exact_certificate():
    # Concavity reduces a's best response to floor/ceiling of the vertex.
    br = []
    for j in GRID:
        lo = max(0, min(600, (800 + 2 * j) // 6))
        candidates = sorted({lo, min(600, lo + 1)})
        br.append(max(candidates, key=lambda i: (profit(i, j), -i)))
    off = [profit(j, br[j]) for j in GRID]
    ordered = sorted(GRID, key=lambda j: (-off[j], j))
    best = None
    second = None
    winners = []
    high_responses = 0
    target_result = None
    for r in GRID:
        for q in GRID:
            j_off = next(j for j in ordered if j != q)
            comply = profit(q, r) >= off[j_off]
            j = q if comply else j_off
            i = r if comply else br[j]
            value = profit(i, j)
            row = (r, q, i, j, value, profit(j, i), comply)
            if best is None or value > best:
                second = best
                best = value
                winners = [row]
            elif value == best:
                winners.append(row)
            elif second is None or value > second:
                second = value
            high_responses += i >= 300 and j >= 300
            if r == 200 and q == 200:
                target_result = row
    assert winners == [(387, 430, 387, 430, 193113, 122120, True)]
    assert second == 193060
    assert target_result[2:4] == (210, 229)
    assert high_responses == 54304
    r, q = winners[0][:2]
    j_off = next(j for j in ordered if j != q)
    compliance_gap = profit(q, r) - off[j_off]
    assert compliance_gap == 63
    gap = Fraction(best - second, DEN)
    beta = Fraction(19, 20)
    root_gap = beta**2 * gap
    return {
        "model": "BM-FG-TURN-0.005-v0.4",
        "arithmetic": "Python integers and fractions.Fraction; no floating-point comparisons",
        "price_grid": {"numerators": [0, 600], "denominator": 200},
        "trigger_pairs_enumerated": 601**2,
        "unique_optimal_trigger_indices": [r, q],
        "optimal_prices": [str(Fraction(r, 200)), str(Fraction(q, 200))],
        "optimal_profits": [str(Fraction(best, DEN)), str(Fraction(winners[0][5], DEN))],
        "best_off_target_b_profit": str(Fraction(off[j_off], DEN)),
        "compliance_gap": str(Fraction(compliance_gap, DEN)),
        "second_best_a_profit": str(Fraction(second, DEN)),
        "algorithm_selection_gap": str(gap),
        "discount": str(beta),
        "root_one_shot_gap": str(root_gap),
        "intervention_trigger_indices": [200, 200],
        "intervention_settled_indices": list(target_result[2:4]),
        "intervention_settled_prices": [str(Fraction(x, 200)) for x in target_result[2:4]],
        "root_states": 601**2,
        "response_states": 601**2,
        "all_states": 2 * 601**2,
        "high_root_states": 301**2,
        "high_response_states": high_responses,
        "region_states": 301**2 + high_responses,
        "baseline_survival_on_B1": "1",
        "intervened_survival_on_B1": "0",
        "uniform_survival_gap": "1",
        "threshold_interval": {"left_open": "21/20", "right_closed": "387/200"},
        "scope": "Exact arithmetic and structural calculations in the declared finite deterministic game; not independent theorem-prover replay or an empirical certificate."
    }


if __name__ == "__main__":
    result = exact_certificate()
    output = Path(__file__).with_name("brown_mackay_exact_certificate.json")
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
